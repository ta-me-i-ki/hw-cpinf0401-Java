
package lab04;


public class Car {
    private String manufacturer;
    private String model;
    private int year;
    private int price;
    private String color;
    
    // default contrsuctor 
    
    public Car() {
        manufacturer = "Toyota";
        model = "Rav4";
        year = 2020;
        price = 20000;
        color = "Red";
    }
    
    // non-default constructor 1
    
    public Car (String manufacturer, String model, int year, int price, String color){
        this.manufacturer = manufacturer;
        this.model = model;
        this.year = year;
        this.price = price;
        this.color = color;
    }
    
    // non-default contrsuctor 2
    
    public Car (String manufacturer, String model) {
        this.manufacturer = manufacturer;
        this.model = model;
        year = 2024;
        price = 36000;
        color = "Black";
    }
    
    // non-default cobstructor 3
    
    public Car (String rawData) {
        String[] info = rawData.split(",");
        manufacturer = info[0];
        model = info[1];
        year = Integer.parseInt(info[2].trim());
        price = Integer.parseInt(info[3].trim());
        color = info[4];
    }
    
    // getters

    public String getManufacturer() {
        return manufacturer;
    }

    public String getModel() {
        return model;
    }

    public int getYear() {
        return year;
    }

    public int getPrice() {
        return price;
    }

    public String getColor() {
        return color;
    }
    
    // setters

    public void setManufacturer(String manufacturer) {
        if (manufacturer.equalsIgnoreCase("Toyota")
                ||manufacturer.equalsIgnoreCase("Ford")
                || manufacturer.equalsIgnoreCase("Nissan")){
            this.manufacturer = manufacturer;
        } else {
            System.out.println("Invalid manufacturer: " + manufacturer);
        } 
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setYear(int year) {
        if (year>=2015 && year<=2023){
           this.year = year; 
        } else {
            System.out.println("Invalid year: " + year);
        }   
    }

    public void setPrice(int price) {
        if (price>=20000 && price<=30000){
           this.price = price; 
        } else {
            System.out.println("Invalid price: " + price);
        }   
    }

    public void setColor(String color) {
        if (color.equalsIgnoreCase("Black")
                ||color.equalsIgnoreCase("White")
                || color.equalsIgnoreCase("Gray")
                || color.equalsIgnoreCase("Red")){
            this.color = color;
        } else {
            System.out.println("Invalid color: " + color);
        } 
    }
    
    // methods
    
    public String carInfo() {
        StringBuilder sb = new StringBuilder();
        sb.append("Car info: ").append("\n");
        sb.append("Manufacturer: ").append(manufacturer).append("\n");
        sb.append("Model: ").append(model).append("\n");
        sb.append("Year: ").append(year).append("\n");
        sb.append("Price: ").append(price).append("\n");
        sb.append("Color: ").append(color).append("\n");
        return sb.toString();
        
    }
    
    public boolean isCarFromSameManufacturerandModel(Car car){
        return car.getManufacturer().equalsIgnoreCase(manufacturer)&& car.getModel().equalsIgnoreCase(model);
    }
}
