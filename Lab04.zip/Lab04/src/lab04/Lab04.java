
package lab04;


public class Lab04 {

    
    public static void main(String[] args) {
        Car car01 = new Car();
        System.out.println(car01.carInfo());
        Car car02 = new Car("Ford", "Sport", 2024, 30000, "Gray");
        System.out.println(car02.carInfo());
        Car car03 = new Car("Ford", "Sport");
        System.out.println(car03.carInfo());
        Car car04 = new Car("Ferrari, Eco, 2021, 100000, Green");
        System.out.println(car04.carInfo());
        
        
        // testing setters and getters
        car01.setColor("blue");
        System.out.println(car01.getColor());
        
        car01.setColor("black");
        System.out.println(car01.getColor());
        
        car02.setManufacturer("rainbow");
        System.out.println(car02.getManufacturer());
        
        car02.setManufacturer("Nissan");
        System.out.println(car02.getManufacturer());
        
        car03.setPrice(500);
        System.out.println(car03.getPrice());
        
        car03.setPrice(25000);
        System.out.println(car03.getPrice());
        
        car04.setModel("sport");
        System.out.println(car04.getModel());
        
        car01.setYear(2000);
        System.out.println(car01.getYear());
        
        car01.setYear(2017);
        System.out.println(car01.getYear());
        
    }
    
}
