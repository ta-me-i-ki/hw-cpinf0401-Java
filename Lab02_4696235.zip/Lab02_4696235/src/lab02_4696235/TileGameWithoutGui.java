package lab02_4696235;

import java.util.Arrays;
import java.util.Scanner;

public class TileGameWithoutGui {

    private static int[][] gameBoard;

    public static void main(String[] args) {
        new TileGameWithoutGui();
    }

    public TileGameWithoutGui() {
        boolean gameOver = false;
        initializeGame();
        while (!gameOver) {
            displayGame();
            int tileNumber = getTileNumber();
            int[] tilePosition = getTilePosition(tileNumber);
            int[] emptySpotPosition = getTilePosition(0);
            if (canTileBeMoved(tilePosition, emptySpotPosition)) {
                moveTile(tilePosition, emptySpotPosition);
                if (isGameOver()) {
                    gameOver = true;
                }
            }
        }
        displayGame();
    }

    private static void initializeGame() {
        gameBoard = new int[][]{{2, 8, 6, 3},
        {1, 9, 4, 11},
        {10, 15, 7, 13},
        {0, 5, 12, 14}};

    }

    private static void displayGame() {
        for (int[] row : gameBoard) {
            for (int tile : row) {
                System.out.print(tile + " ");
            }
            System.out.println("");
        }
    }

    private static int getTileNumber() {
        Scanner keyboard = new Scanner(System.in);
        int userInput = -1;
        boolean ValidInput = false;
        while (!ValidInput) {
            System.out.print("Enter Tile Number: ");
            userInput = keyboard.nextInt();
            if (userInput >= 0 && userInput <= 15) {
                ValidInput = true;
            } else {
                System.out.println("Wrong number! Please try again.");
            }
        }
        return userInput;
    }

    private static int[] getTilePosition(int tileNumber) {
        int rowNumber = 0;
        int columnNumber = 0;
        for (int row = 0; row < gameBoard.length; row++) {
            for (int column = 0; column < gameBoard[row].length; column++) {
                if (gameBoard[row][column] == tileNumber) {
                    rowNumber = row;
                    columnNumber = column;
                }
            }
        }

        return new int[]{rowNumber, columnNumber};
    }

    private static boolean canTileBeMoved(int[] tilePosition,
            int[] emptySpotPosition) {
        if ((emptySpotPosition[0] == tilePosition[0] - 1)
                && (emptySpotPosition[1] == tilePosition[1])) {
            return true;
        } else if ((emptySpotPosition[0] == tilePosition[0] + 1)
                && (emptySpotPosition[1] == tilePosition[1])) {
            return true;
        } else if ((emptySpotPosition[0] == tilePosition[0])
                && (emptySpotPosition[1] == tilePosition[1] - 1
                || emptySpotPosition[1] == tilePosition[1] + 1)) {
            return true;
        } else {
            return false;
        }

    }

    private static void moveTile(int[] tilePosition, int[] emptySpotPosition) {
        gameBoard[emptySpotPosition[0]][emptySpotPosition[1]] = gameBoard[tilePosition[0]][tilePosition[1]];
        gameBoard[tilePosition[0]][tilePosition[1]] = 0;
    }

    private static boolean isGameOver() {
        int correctTile = 1;
        for (int[] row : gameBoard) {
            for (int tile : row) {
                if (correctTile == 16) {
                    break;
                }
                if (tile != correctTile) {
                    return false;
                }
                correctTile += 1;
            }
        }
        return true;
    }

}
