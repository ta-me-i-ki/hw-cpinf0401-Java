
package lab06;

public class Mouse {
    //class fields
    public String connectivityType;
    public String brand;
    
    //class constructors
    public Mouse() {
        connectivityType = "Bluetooth";
        brand = "Logitec";
    }
    
    // class methods
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== Mouse features ===\n");
        sb.append("\t\t\tConnectivity type: ").append(connectivityType).append("\n");
        sb.append("\t\t\tBrand: ").append(brand).append("\n");
        return sb.toString();
    }
    
}
