
package lab06;


public class Lab06 {

    
    public static void main(String[] args) {
        // computer system 1
        GamingKeyboard gamingKeyboard = new GamingKeyboard("logitec,", 100, "Pokemon theme", 7);
        Monitor monitor1 = new Monitor("LG", 21, "1080x720");
        Mouse mouse1 = new Mouse();
        ComputerSystem computerSystem1 = new ComputerSystem("Dell", 599, monitor1, gamingKeyboard, mouse1);
        
        // computer system 2
        VisionImparedKeyboard visionKeyboard = new VisionImparedKeyboard("Dell", 200, true, true);
        visionKeyboard.paintKeyboardBody("yellow", true);
        Monitor monitor2 = new Monitor("LG", 27, "2080x1720");
        Mouse mouse2 = new Mouse();
        mouse2.brand = "Windows";
        mouse2.connectivityType = "USB";
        ComputerSystem computerSystem2 = new ComputerSystem("Dell", 899, monitor2, visionKeyboard, mouse2);
        
        // computer system 3
        Keyboard keyboard = new Keyboard("KeyGen", 49);
        keyboard.paintKeyboardBody("cyan", false);
        Monitor monitor3 = new Monitor("ViewSonic", 27, "3500x200");
        Mouse mouse3 = new Mouse();
        ComputerSystem computerSystem3 = new ComputerSystem("Razor", 2000, monitor3, keyboard, mouse3);
        
        // comparing
        System.out.println(computerSystem1.equals(computerSystem2));
        System.out.println(computerSystem2.equals(computerSystem3));
        System.out.println(computerSystem1.equals(computerSystem3));
        
    }
    
}
