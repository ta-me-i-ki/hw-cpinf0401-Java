
package lab06;

public class VisionImparedKeyboard extends Keyboard{
    //class fields
    public boolean keypressedSound;
    public boolean brailleKeyStyle;
    
    //class contructors
    public VisionImparedKeyboard (String brand, double price, boolean keypressedSound, 
            boolean brailleKeyStyle){
        super(brand, price);
        this.keypressedSound = keypressedSound;
        this.brailleKeyStyle = brailleKeyStyle;
    }
    
    //class methods
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("\t\t\t=== Vision Impaired Features ===\n");
        sb.append("\t\t\t\t\t\tKeypressed Sound: ").append(keypressedSound).append("\n");
        sb.append("\t\t\t\t\t\tBraille Option: ").append(brailleKeyStyle).append("\n");
        return sb.toString();
    }
    
}
