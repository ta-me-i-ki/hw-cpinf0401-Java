
package lab06;

public class Keyboard {
    //class fields
    public String brand;
    public double price;
    
    //class constructor
    public Keyboard(String brand, double price) {
        this.brand = brand;
        this.price = price;
    }
    
    //class methods
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== Keyboard features ===\n");
        sb.append("\t\t\tBrand: ").append(brand).append("\n");
        sb.append("\t\t\tPrice: ").append(price).append("\n");
        return sb.toString();
    }
    
    public void paintKeyboardBody(String color){
        System.out.println("");
    }
    
    public void paintKeyboardBody(String color, boolean gradient){
        System.out.println("");
    }
    
}
