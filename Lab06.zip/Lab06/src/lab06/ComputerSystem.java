
package lab06;


public class ComputerSystem {
    // class fields
    public String brand;
    public double price;
    public Monitor monitor;
    public Keyboard keyboard;
    public Mouse mouse;
    
    // class constructors
    public ComputerSystem(String brand, int price, Monitor monitor, 
            Keyboard keyboard, Mouse mouse) {
        this.brand = brand;
        this.price = price;
        this.monitor = monitor;
        this.keyboard = keyboard;
        this.mouse = mouse;            
    }
    
    // class methods
    @Override
    public String toString (){
        StringBuilder sb = new StringBuilder();
        sb.append("=== Computer System ===\n");
        sb.append("\t\t\tBrand: ").append(brand).append("\n");
        sb.append("\t\t\tPrice: ").append(price).append("\n");
        sb.append("\t\t\t").append(monitor).append("\n");
        sb.append("\t\t\t").append(keyboard).append("\n");
        sb.append("\t\t\t").append(mouse).append("\n");
        return sb.toString();
    }
    
    public boolean equals(ComputerSystem computerSystem2){
        return Math.abs(this.price - computerSystem2.price) < 100.00 
                && this.monitor.size == computerSystem2.monitor.size
                && this.brand.equals(computerSystem2.brand);
    }
}
