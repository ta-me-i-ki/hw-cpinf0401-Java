
package lab06;

public class Monitor {
    // class fields
    public String brand;
    public int size;
    public String resolution;
    
    // class contrsuctors 
    public Monitor(String brand, int size, String resolution) {
        this.brand = brand;
        this.size = size;
        this.resolution = resolution;
    }
   
    //class methods 
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== Monitor features ===\n");
        sb.append("\t\t\tBrand: ").append(brand).append("\n");
        sb.append("\t\t\tSize: ").append(size).append("\n");
        sb.append("\t\t\tResolution: ").append(resolution).append("\n");
        return sb.toString();
    }
    
}
