
package lab06;


public class GamingKeyboard extends Keyboard{
    // class fields
    public String themeColor;
    public int lightConfiguration;
    
    //class contrsuctors
    public GamingKeyboard(String brand, double price, String themeColor, 
            int lightConfiguration){
        super(brand, price);
        this.themeColor = themeColor;
        this.lightConfiguration = lightConfiguration;
    }
    
    //class methods
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("\t\t\t=== Gaming Features ===\n");
        sb.append("\t\t\t\t\t\tTheme Color: ").append(themeColor).append("\n");
        sb.append("\t\t\t\t\t\tLight Configuration: ").append(lightConfiguration).append("\n");
        return sb.toString();
    }
    
}
