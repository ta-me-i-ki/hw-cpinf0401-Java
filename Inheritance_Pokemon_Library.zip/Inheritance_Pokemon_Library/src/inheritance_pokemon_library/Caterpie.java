package inheritance_pokemon_library;

public class Caterpie extends Pokemon{
    // class default constructor 
    public Caterpie() {
        type = "Bug";
        height = 12.0;
        weight = 6.4;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("======  Caterpie  =====").append("\n");
        sb.append("Caterpie is a small Bug-type Pokemon that resembles a ").append("\n");
        sb.append("caterpillar. Green with a yellow belly and red eyebrows, ").append("\n");
        sb.append("Caterpie blends in with its forest surroundings, using its ").append("\n");
        sb.append("suction-cup feet to climb up trees unnoticed by predators.").append("\n");
        return sb.toString();
    }
    
    @Override
    public String getAdvantage() {
        StringBuilder sb = new StringBuilder();
        sb.append("======  Caterpie Advantages  =====").append("\n");
        sb.append("Caterpie uses string shot in combat against opponents. ").append("\n");
        sb.append("It only takes half the normal damage from Grass, Fighting, ").append("\n");
        sb.append("and Ground-type moves.").append("\n");
        return sb.toString();
    }
    
    @Override
    public String getDisadvantage() {
        StringBuilder sb = new StringBuilder();
        sb.append("======  Caterpie Disadvantages  =====").append("\n");
        sb.append("As a Bug-type Pokemon, Caterpie takes double the damage from ").append("\n");
        sb.append("Fire , Flying, and Rock-type attacks.").append("\n");
        return sb.toString();
    }
}
