package inheritance_pokemon_library;

public class Charmander extends Pokemon{
    // class default constructor
    public Charmander() {
        type = "Fire";
        height = 24.0;
        weight = 18.7;
    }
        
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("======  Charmander  =====").append("\n");
        sb.append("Charmander is a Fire-type Pokemon, and resembles a small ").append("\n");
        sb.append("dinosaur, its red skin and flaming tail giving it an ").append("\n");
        sb.append("appearance indicative of its type. Typical moves include ").append("\n");
        sb.append("Ember and Tail Whip.").append("\n");
        return sb.toString();
    }
    
    @Override
    public String getAdvantage() {
        StringBuilder sb = new StringBuilder();
        sb.append("======  Charmander Advantages  =====").append("\n");
        sb.append("As a Fire-type Pokemon, Charmander only takes half of the ").append("\n");
        sb.append("normal damage from Fire, Ice, Grass, Bug, and Steel-types.").append("\n");
        return sb.toString();
    }
            
    @Override
    public String getDisadvantage() {
        StringBuilder sb = new StringBuilder();
        sb.append("======  Charmander Disadvantages  =====").append("\n");
        sb.append("Charmander takes double the normal damage from Water, Ground, ").append("\n"); 
        sb.append("and Rock-types.").append("\n"); 
        return sb.toString();
    }
}
