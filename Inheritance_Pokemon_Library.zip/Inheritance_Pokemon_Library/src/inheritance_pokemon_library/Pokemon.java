package inheritance_pokemon_library;

public abstract class Pokemon {
    // class fields
    public String type;
    public double height;
    public double weight;
    
    // class methods
    public String getCopyrightStatement() {
        StringBuilder sb = new StringBuilder();
        sb.append("======  Copyright Statement  =====").append("\n");
        sb.append("Pokemon and Pokemon character names are trademark of Nintendo, ").append("\n");
        sb.append("no copyright infringement intended. Pokemon (C) 2002-2023").append("\n\n");
        return sb.toString();       
    }
    
    public abstract String getDisadvantage();
    
    public abstract String getAdvantage();
    
}
