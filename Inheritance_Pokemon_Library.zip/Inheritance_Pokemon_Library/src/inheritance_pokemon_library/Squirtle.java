package inheritance_pokemon_library;

public class Squirtle extends Pokemon{
    // class default constructor
    public Squirtle() {
        type = "Water";
        height = 12.8;
        weight = 19.8;
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("======  Squirtle  =====").append("\n");
        sb.append("Squirtle is one of the starter Pokemon available from ").append("\n");
        sb.append("Professor Oak at the beginning of the Pokémon Red/Blue games. ").append("\n");
        sb.append("As a Water-type Pokemon, Squirtle is able to use attacks ").append("\n");
        sb.append("such as Water Gun and Bubble, as well as the HM ability ").append("\n");
        sb.append("Surf which allows players to ride on a Pokemon over sections ").append("\n");
        sb.append("of water.").append("\n");
        return sb.toString();
    }
    
    @Override
    public String getAdvantage() {
        StringBuilder sb = new StringBuilder();
        sb.append("======  Squirtle Advantages  =====").append("\n");
        sb.append("As a Water-type Pokemon, Squirtle takes double the damage ").append("\n");
        sb.append("from Electric and Grass-type moves.").append("\n");
        return sb.toString();
    }
    
    @Override
    public String getDisadvantage() {
        StringBuilder sb = new StringBuilder();
        sb.append("======  Squirtle Disadvantages  =====").append("\n");
        sb.append("Squirtle only takes half the normal damage from Fire, ").append("\n");
        sb.append("Water, Ice, and Steel-type attacks.").append("\n");
        return sb.toString();
    }
}
