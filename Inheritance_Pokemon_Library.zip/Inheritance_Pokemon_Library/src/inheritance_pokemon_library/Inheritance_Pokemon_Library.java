package inheritance_pokemon_library;

import java.util.ArrayList;
import java.util.List;

public class Inheritance_Pokemon_Library {

    public static void main(String[] args) {
        new Inheritance_Pokemon_Library();
    }
    
    public Inheritance_Pokemon_Library() {
        // create some pokemons here
        Bulbasaur bulbasaur = new Bulbasaur();
//        System.out.println(bulbasaur);
//        System.out.println(bulbasaur.getAdvantage());
//        System.out.println(bulbasaur.getDisadvantage());
//        System.out.println(bulbasaur.getCopyrightStatement());
        
        Caterpie caterpie = new Caterpie();
//        System.out.println(caterpie);
//        System.out.println(caterpie.getAdvantage());
//        System.out.println(caterpie.getDisadvantage());
//        System.out.println(caterpie.getDisadvantage());
        
        Charmander charmander = new Charmander();
//        System.out.println(charmander);
//        System.out.println(charmander.getAdvantage());
//        System.out.println(charmander.getDisadvantage());
//        System.out.println(charmander.getCopyrightStatement());
        
        Squirtle squirtle = new Squirtle();
//        System.out.println(squirtle);
//        System.out.println(squirtle.getAdvantage());
//        System.out.println(squirtle.getDisadvantage());
//        System.out.println(squirtle.getCopyrightStatement());
        
        List<Pokemon> pokemons = new ArrayList();
        pokemons.add(squirtle);
        pokemons.add(bulbasaur);
        pokemons.add(charmander);
        pokemons.add(caterpie);
        
        for (Pokemon pokemon : pokemons) {
            System.out.println(pokemon);
            System.out.println(pokemon.getAdvantage());
            System.out.println(pokemon.getDisadvantage());
            System.out.println(pokemon.getCopyrightStatement());
        }

    }
}
