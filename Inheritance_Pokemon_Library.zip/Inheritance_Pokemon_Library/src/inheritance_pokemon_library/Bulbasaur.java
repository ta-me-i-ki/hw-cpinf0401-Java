package inheritance_pokemon_library;

public class Bulbasaur extends Pokemon{ 
    public Bulbasaur() {
        type = "Grass & Poison";
        height = 28.0;
        weight = 15.2;
    } 
   
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("======  Bulbasaur  =====").append("\n");
        sb.append("Bulbasaur is classified as a Seed Pokemon. It is well ").append("\n");
        sb.append("known as one of the three starter Pokemon in Versions Red & ").append("\n");
        sb.append("Blue, as well as the remakes, Versions Leaf Green & Fire Red. ").append("\n");
        sb.append("It is the only of the first three starter Pokemon that ").append("\n");
        sb.append("possesses two types (Grass & Poison).").append("\n");
        return sb.toString();
    }
    
    @Override
    public String getAdvantage() {
        StringBuilder sb = new StringBuilder();
        sb.append("======  Bulbasaur Advantages  =====").append("\n");
        sb.append("Bulbasaur has an advantage over Water, Electric, and ").append("\n");
        sb.append("Fighting-types, only taking half of the usual damage from ").append("\n");
        sb.append("these types of moves. It has an even greater advantage over ").append("\n");
        sb.append("Grass types, only taking 25% damage from attacks of these type.").append("\n");
        return sb.toString();
    }
    
    @Override
    public String getDisadvantage() {
        StringBuilder sb = new StringBuilder();
        sb.append("======  Bulbasaur Disadvantages  =====").append("\n");
        sb.append("Bulbasaur takes double the damage from Fire, Flying, and ").append("\n");
        sb.append("Psychic-type moves.").append("\n");
        return sb.toString();
    }
}
