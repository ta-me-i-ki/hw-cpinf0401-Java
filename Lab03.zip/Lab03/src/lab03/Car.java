
package lab03;


public class Car {
    public String manufacturer;
    public String model;
    public int year;
    public int price;
    public String color;
    
    // default contrsuctor 
    
    public Car() {
        manufacturer = "Toyota";
        model = "Rav4";
        year = 2020;
        price = 20000;
        color = "Red";
    }
    
    // non-default constructor 1
    
    public Car (String manufacturer, String model, int year, int price, String color){
        this.manufacturer = manufacturer;
        this.model = model;
        this.year = year;
        this.price = price;
        this.color = color;
    }
    
    // non-default contrsuctor 2
    
    public Car (String manufacturer, String model) {
        this.manufacturer = manufacturer;
        this.model = model;
        year = 2024;
        price = 36000;
        color = "Black";
    }
    
    // non-default cobstructor 3
    
    public Car (String rawData) {
        String[] info = rawData.split(",");
        manufacturer = info[0];
        model = info[1];
        year = Integer.parseInt(info[2].trim());
        price = Integer.parseInt(info[3].trim());
        color = info[4];
    }
    
    
    
}
