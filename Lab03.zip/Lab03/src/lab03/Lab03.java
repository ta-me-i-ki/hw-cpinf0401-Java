
package lab03;


public class Lab03 {

    
    public static void main(String[] args) {
        Car car01 = new Car();
        Car car02 = new Car("Ford", "Sport", 2024, 30000, "Gray");
        Car car03 = new Car("Ford", "Sport");
        Car car04 = new Car("Ferrari, Eco, 2021, 100000, Green");
        
        Car[] availableCars = {car01, car02, car03, car04};
        
        int counter = 1;
        for (Car item : availableCars) {
            System.out.println("Car " + counter + " info:");
            counter +=1;
            System.out.println("Manufacturer: " + item.manufacturer);
            System.out.println("Model: " + item.model);
            System.out.println("Year: " + item.year);
            System.out.println("Price: " + item.price);
            System.out.println("Color: " + item.color);
            System.out.println("");
        }
    }
    
}
