package lab01_4696235;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class Lab01_4696235 {

    public static void main(String[] args) {
//        activity_1();
//        activity_2();
//        activity_3();
//        activity_4();
//        activity_5();
        activity_6();
//        activity_7();
//        activity_8();
//        activity_9();
//        activity_10();
    }
        
    private static void activity_1() {
        byte level = 1;
        short year = 2024;
        int myAge = 19;
        long value = 8639020;
        double temperature = 7.7;
        float arg = 13.7f;
        String name = "Sasha";
        boolean isRaining = false;
        boolean isSnowing = true;
        System.out.println("Level: " + level + " , Year: " + year);
        System.out.println("Age: " + myAge + " , Value: " + value);
        System.out.println("Temp: " + temperature + " , Arg: " + arg);
        System.out.println("Name: " + name + " , Is it raining?: " + isRaining);
        System.out.println("Is it snowing? " + isSnowing); }

    private static void activity_2() {
        int time = 12345;
        int hours = time / 3600;
        int minutes = time % 3600 / 60;
        int seconds = time % 3600 % 60;
        System.out.println("Hours: " + hours + ", minutes: " 
                + minutes + ", seconds: " + seconds);
    }
    
    private static void activity_3() {
        double radius = 5.0;
        double volume = 4 / 3.0 * Math.PI * Math.pow(radius, 3);
        System.out.println(volume);
    }
    
    private static void activity_4() {
        int age = 23;
        if (age >= 16) {
            System.out.println("The subject can get a driver license");
        } else {
            System.out.println("The subject cannot get a driver license yet");
        }
    }
    
    private static void activity_5() {
        double measured = 11.00;
        double standard = 10.0;
        double tolerance = 0.05;
        if (Math.abs(measured - standard) < tolerance) {
            System.out.println("Pass");
        } else {
            System.out.println("No pass");
        }
    }
    
    private static void activity_6() {
        for (int i = -180; i <= 180; i++) {
            System.out.println(i + " | " + Math.sin(i * Math.PI / 180.0));
        }
    }
    
    private static void activity_7() {
        String[] names = {"Alex", "Levy", "Sasha", "Leyla", "Bri"};
        for (String item : names) {
            System.out.println(item);
        } 
    }
    
    private static void activity_8() {
        Scanner keyboard = new Scanner(System.in);
        int range1 = 50;
        int range2 = 100;
        while(true){
            System.out.print("Please enter the number between 50 and 100: ");
            int number = keyboard.nextInt();
            if(number>=range1 && number<=range2) {
                break;
            } else {
            System.out.println("Wrong number! Please try again.");}
        }
    }
    
    private static void activity_9() {      
        double radiusInput = Double.parseDouble(JOptionPane.showInputDialog("Enter the radius: "));
        double volumeForInput = 4 / 3.0 * Math.PI * Math.pow(radiusInput, 3);
        JOptionPane.showMessageDialog(null, "The radius is " + volumeForInput);
    }
    
    private static void activity_10() {
        int max = 50;
        int min = -50;
        for (int i=0; i<10; i++){ 
            System.out.println((int)(Math.random() * (max - min) + min));
        }
    }
        
}
